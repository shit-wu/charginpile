// import instance from "../network/request"

// export function auth() {
// 	return instance({
// 		url: "/token",
// 		method: "get",
// 	})
// }
// import axios from 'axios'

// axios({
// 	method: 'get',
// 	url: '/api/token',

// })